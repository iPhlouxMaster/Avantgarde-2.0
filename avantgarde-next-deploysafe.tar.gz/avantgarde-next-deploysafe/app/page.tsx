import Link from "next/link";
export default function Home(){
  return(<main className="max-w-3xl mx-auto p-6 mt-10 space-y-6">
    <h1 className="text-3xl font-bold">Avantgarde × SouthStar</h1>
    <p className="text-lg text-gray-300">Deploy-safe Next.js app with Supabase + tokens pipeline.</p>
    <div className="grid md:grid-cols-2 gap-4">
      <Link href="/auth" className="card block"><h2 className="text-xl font-semibold mb-2">Auth</h2><p>Supabase magic link sign-in.</p></Link>
      <Link href="/quote" className="card block"><h2 className="text-xl font-semibold mb-2">Get Quotes</h2><p>Call Edge Wrapper for quotes.</p></Link>
      <Link href="/bind" className="card block"><h2 className="text-xl font-semibold mb-2">Bind Policy</h2><p>Bind the selected quote.</p></Link>
      <Link href="/factorfox-sync" className="card block"><h2 className="text-xl font-semibold mb-2">FactorFox Sync</h2><p>Push limits & customer.</p></Link>
    </div>
  </main>);
}
