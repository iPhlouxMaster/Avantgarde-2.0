"use client";
import { supabase } from "@/lib/supabase";
import { useState } from "react";
export default function AuthPage(){
  const [email,setEmail]=useState(""); const [sent,setSent]=useState(false);
  async function signIn(){ const { error } = await supabase.auth.signInWithOtp({ email }); if(!error) setSent(true); else alert(error.message); }
  return(<div className="max-w-md mx-auto mt-24 card">
    <h1 className="text-2xl font-bold mb-4">Sign in</h1>
    <input className="input mb-3" placeholder="you@company.com" value={email} onChange={(e)=>setEmail(e.target.value)} />
    <button onClick={signIn} className="btn btn-primary">{sent?"Check your email":"Send magic link"}</button>
  </div>);
}
