"use client";
import { useState } from "react";
import { safePost } from "@/lib/safeFetch";
export default function BindPage(){
  const [quoteJson,setQuoteJson]=useState(""); const [requestJson,setRequestJson]=useState(""); const [resp,setResp]=useState<any>(null);
  async function bind(){ try{ const body={ quote: JSON.parse(quoteJson), request: JSON.parse(requestJson) }; const r=await safePost("/api/v1/insure/bind", body); setResp(r.ok?r.data:{ error:r.error }); }catch(e:any){ setResp({ error:e.message }); } }
  return(<div className="max-w-4xl mx-auto p-6 mt-8 card">
    <h1 className="text-2xl font-bold mb-4">Bind Policy</h1>
    <div className="grid md:grid-cols-2 gap-4">
      <textarea placeholder="Paste chosen quote JSON" className="h-56 input" value={quoteJson} onChange={(e)=>setQuoteJson(e.target.value)} />
      <textarea placeholder="Paste original request JSON" className="h-56 input" value={requestJson} onChange={(e)=>setRequestJson(e.target.value)} />
    </div>
    <button onClick={bind} className="mt-3 btn btn-primary">Bind</button>
    {resp && <pre className="mt-4 bg-bg p-4 rounded-xl overflow-auto">{JSON.stringify(resp,null,2)}</pre>}
  </div>);
}
