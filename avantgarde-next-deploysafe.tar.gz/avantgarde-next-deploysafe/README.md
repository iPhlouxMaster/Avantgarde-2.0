# Avantgarde × SouthStar — Next.js Console (Deploy-safe)
Quick start:
- pnpm i
- cp .env.example .env
- pnpm tokens
- pnpm dev (http://localhost:3000)

Deploy to Vercel: push to GitHub, import, add env vars, deploy.
