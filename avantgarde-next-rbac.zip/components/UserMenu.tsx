"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export function UserMenu(){
  const [email,setEmail]=useState<string|undefined>("");
  useEffect(()=>{ (async ()=>{
    const { data: { user } } = await supabase.auth.getUser();
    setEmail(user?.email||"");
  })(); },[]);
  async function signOut(){ await supabase.auth.signOut(); location.href="/auth"; }
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-muted">{email}</span>
      <button onClick={signOut} className="btn btn-secondary">Sign out</button>
    </div>
  );
}
