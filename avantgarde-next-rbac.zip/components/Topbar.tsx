"use client";
import { BrandLogo } from "./BrandLogo";
import { OrgSwitcher } from "./OrgSwitcher";
import { UserMenu } from "./UserMenu";

export function Topbar(){
  return (
    <header className="h-14 sticky top-0 bg-surface border-b border-[#1b2330] flex items-center justify-between px-4">
      <BrandLogo />
      <div className="flex items-center gap-3">
        <OrgSwitcher />
        <UserMenu />
      </div>
    </header>
  );
}
