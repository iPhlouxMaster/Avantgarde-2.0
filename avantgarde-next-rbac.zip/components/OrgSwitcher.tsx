"use client";
import { useOrg } from "@/lib/org";

export function OrgSwitcher(){
  const { orgs, org, setOrgId } = useOrg();
  return (
    <select className="input !py-1 !px-2" value={org?.id||""} onChange={(e)=>setOrgId(e.target.value)}>
      {orgs.map(o=>(<option key={o.id} value={o.id}>{o.name}</option>))}
    </select>
  );
}
