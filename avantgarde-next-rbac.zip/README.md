# Avantgarde Console — RBAC + Org + Shell

A Next.js console styled like an investment bank system: orgs, roles (admin/analyst/viewer),
workflow visibility, audit log, settings, and a polished shell.

## Quick Start
```bash
pnpm i
cp .env.example .env
pnpm tokens
pnpm dev  # http://localhost:3000
```
Run `supabase/schema_rbac.sql` in Supabase SQL editor to create orgs/members/profiles (+ RLS).

## Deploy
Push to GitHub → Import on Vercel → add env vars → deploy.
