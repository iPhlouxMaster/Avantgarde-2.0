"use client";
import SyncPage from "@/app/factorfox-sync/page";
export default SyncPage;
