"use client";
import BindPage from "@/app/bind/page";
export default BindPage;
