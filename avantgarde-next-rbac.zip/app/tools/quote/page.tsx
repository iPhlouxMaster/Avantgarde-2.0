"use client";
import QuotePage from "@/app/quote/page";
export default QuotePage;
