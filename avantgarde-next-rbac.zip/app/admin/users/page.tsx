"use client";
import { AppShell } from "@/components/AppShell";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
export default function UsersPage(){
  const [rows,setRows]=useState<any[]>([]);
  useEffect(()=>{ (async()=>{
    const { data } = await supabase.from("members").select("id, role, orgs:org_id(name), profiles:user_id(full_name, email)");
    setRows(data||[]);
  })(); },[]);
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Users</h1>
    <div className="card">
      <table className="w-full text-sm">
        <thead><tr className="text-left text-muted"><th className="py-2">Name</th><th>Email</th><th>Org</th><th>Role</th></tr></thead>
        <tbody>{rows.map((r:any)=>(<tr key={r.id} className="border-t border-[#1b2330]">
          <td className="py-2">{r.profiles?.full_name||"—"}</td>
          <td>{r.profiles?.email||"—"}</td>
          <td>{r.orgs?.name||"—"}</td>
          <td><span className="badge">{r.role}</span></td>
        </tr>))}</tbody>
      </table>
    </div>
  </AppShell>);
}
