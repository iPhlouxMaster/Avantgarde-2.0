"use client";
import { supabase } from "@/lib/supabase";
import { useState } from "react";
export default function AuthPage(){
  const [email,setEmail]=useState(""); const [sent,setSent]=useState(false);
  async function signIn(){ const { error } = await supabase.auth.signInWithOtp({ email }); if(!error) setSent(true); else alert(error.message); }
  return(<div className="max-w-md mx-auto mt-24 card">
    <h1 className="text-2xl font-bold mb-2">Welcome to Avantgarde</h1>
    <p className="text-muted mb-4">Sign in with a magic link.</p>
    <input className="input mb-3" placeholder="you@company.com" value={email} onChange={(e)=>setEmail(e.target.value)} />
    <button onClick={signIn} className="btn btn-primary">{sent?"Check your email":"Send magic link"}</button>
  </div>);
}
