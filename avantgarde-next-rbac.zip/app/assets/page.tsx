"use client";
import { AppShell } from "@/components/AppShell";
export default function AssetsPage(){
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Assets</h1>
    <div className="card">Table placeholder — list assets with status, insurer, pool, exposure.</div>
  </AppShell>);
}
