"use client";
import { AppShell } from "@/components/AppShell";
export default function PoliciesPage(){
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Policies</h1>
    <div className="card">Bind status, coverage %, premium, certificate link.</div>
  </AppShell>);
}
