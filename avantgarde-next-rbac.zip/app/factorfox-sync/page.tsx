"use client";
import { useState } from "react";
import { safePost } from "@/lib/safeFetch";
import { AppShell } from "@/components/AppShell";
export default function SyncPage(){
  const [payload,setPayload]=useState(""); const [resp,setResp]=useState<any>(null);
  async function sync(){ try{ const body=JSON.parse(payload); const r=await safePost("/api/v1/factorfox/sync", body); setResp(r.ok?r.data:{ error:r.error }); }catch(e:any){ setResp({ error:e.message }); } }
  return(<AppShell>
    <h1 className="text-2xl font-bold mb-4">FactorFox Sync</h1>
    <textarea className="w-full h-56 input card" placeholder='{"customer": {...}, "approvedCreditLimit": 250000, "policyId":"COF-123", "insurer":"COFACE"}' value={payload} onChange={(e)=>setPayload(e.target.value)} />
    <button onClick={sync} className="mt-3 btn btn-primary">Sync</button>
    {resp && <div className="card mt-4"><pre>{JSON.stringify(resp,null,2)}</pre></div>}
  </AppShell>);
}
