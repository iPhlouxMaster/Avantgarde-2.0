"use client";
import { useState } from "react";
import { safePost } from "@/lib/safeFetch";
import { AppShell } from "@/components/AppShell";

export default function QuotePage(){
  const [loading,setLoading]=useState(false); const [result,setResult]=useState<any>(null);
  async function onSubmit(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault(); setLoading(true);
    const form = new FormData(e.currentTarget);
    const payload = {
      customer:{ legalName:form.get("legalName"), duns:form.get("duns")||undefined, physicalAddress:{ line1:form.get("addr1"), city:form.get("city"), state:form.get("state"), postalCode:form.get("zip") }, paymentMethods:["ACH"], docsOnFile:["INVOICE"], exposureAtTime:Number(form.get("exposure")||0) },
      requestedCreditLimit:Number(form.get("limit")), buyerCountry:form.get("country")||"US", policyTenorDays:Number(form.get("tenor")||60), deductiblePercent:Number(form.get("deductible")||10)
    };
    const resp = await safePost("/api/v1/insure/quote", payload);
    setResult(resp.ok?resp.data:{ error: resp.error }); setLoading(false);
  }
  return(<AppShell>
    <h1 className="text-2xl font-bold mb-4">Get Trade Credit Quote</h1>
    <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4 card">
      <input name="legalName" required placeholder="Legal Name" className="input" />
      <input name="duns" placeholder="DUNS (optional)" className="input" />
      <input name="addr1" required placeholder="Address line 1" className="input" />
      <input name="city" required placeholder="City" className="input" />
      <input name="state" placeholder="State" className="input" />
      <input name="zip" placeholder="ZIP" className="input" />
      <input name="limit" type="number" required placeholder="Requested Limit ($)" className="input" />
      <input name="exposure" type="number" placeholder="Exposure At Time ($)" className="input" />
      <input name="tenor" type="number" defaultValue={60} className="input" />
      <input name="deductible" type="number" defaultValue={10} className="input" />
      <select name="country" defaultValue="US" className="input"><option value="US">United States</option><option value="CA">Canada</option></select>
      <button disabled={loading} className="md:col-span-2 btn btn-primary">{loading?"Quoting...":"Get Quotes"}</button>
    </form>
    {result&&(<div className="mt-6 card"><h2 className="text-xl font-semibold mb-2">Quotes</h2><pre>{JSON.stringify(result,null,2)}</pre></div>)}
  </AppShell>);
}
