"use client";
import { AppShell } from "@/components/AppShell";
export default function PoolsPage(){
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Pools</h1>
    <div className="card">Positions, NAV, fees, last reconciliation.</div>
  </AppShell>);
}
