-- Orgs / Profiles / Members / Invites
create table if not exists orgs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz default now()
);

create table if not exists profiles (
  id uuid primary key,               -- equals auth.users.id
  email text,
  full_name text,
  created_at timestamptz default now()
);

create table if not exists members (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references orgs(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  role text check (role in ('admin','analyst','viewer')) not null default 'viewer',
  created_at timestamptz default now()
);

create table if not exists invites (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references orgs(id) on delete cascade,
  email text not null,
  role text check (role in ('admin','analyst','viewer')) not null default 'viewer',
  created_by uuid,
  token text unique,
  created_at timestamptz default now()
);

-- Audit log (connect to events table if you imported earlier pack)
create table if not exists audit_log (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references orgs(id) on delete cascade,
  user_id uuid,
  action text,
  entity text,
  entity_id uuid,
  meta jsonb default '{}',
  created_at timestamptz default now()
);

-- Basic RLS (example: user sees only their orgs)
alter table orgs enable row level security;
alter table profiles enable row level security;
alter table members enable row level security;
alter table invites enable row level security;
alter table audit_log enable row level security;

create policy profiles_self on profiles using (id = auth.uid());
create policy members_by_user on members using (user_id = auth.uid());
create policy orgs_by_membership on orgs using (id in (select org_id from members where user_id = auth.uid()));
create policy invites_by_org on invites using (org_id in (select org_id from members where user_id = auth.uid()));
create policy audit_by_org on audit_log using (org_id in (select org_id from members where user_id = auth.uid()));
